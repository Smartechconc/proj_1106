




import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;


public class TestGame {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}
	
	

	@Test
	public void testFlag() {

		Game TestGame = new Game();
		TestGame.createGame("Player 1", "Player 2", "x");
		assertEquals(TestGame.flag, true);
	}
	
	@Test
	public void testFlag2(){
		Game TestGame2 = new Game();
		TestGame2.createGame("Player1", "Player2", "o");
		assertEquals(TestGame2.flag, false);
	}
	
	@Test
	public void testButton(){
		Game TestGame3 = new Game();
		assertNotNull(TestGame3.button);
	}
		
}

	

	
		


