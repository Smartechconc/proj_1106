package com.example.amritpal.tictactoe2;

import android.os.Bundle;

import org.junit.Test;
import com.example.amritpal.tictactoe2.Board;
import static org.junit.Assert.*;

/**
 * Created by Amritpal on 2016-05-29.
 */
public class boardTest {

    @Test
    public void testGetTurnX()
    {
        Board brd=new Board();
        brd.setTurn("x");
        assertEquals(brd.getTurn(),"x");

    }

    @Test
    public void testGetTurnO()
    {
        Board brd=new Board();
        brd.setTurn("o");
        assertEquals(brd.getTurn(),"o");
    }

    @Test
    public void testGetSymbolX()
    {
        Board brd=new Board();
        brd.setSymbol("x");
        assertEquals(brd.getSymbol(),"x");

    }

    @Test
    public void testGetSymbolO() {
        Board brd = new Board();
        brd.setSymbol("o");
        assertEquals(brd.getSymbol(), "o");
    }
}