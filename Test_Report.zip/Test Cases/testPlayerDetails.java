package com.example.amritpal.tictactoe2;

import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Created by amandeepsharma on 2016-05-30.
 */
public class testPlayerDetails {

    @Test
    public void testIsPlayer1Null()
    {
        PlayerDetails player1=new PlayerDetails();
        assertTrue(player1.IsPlayer1Null());
    }

    @Test
    public void testIsPlayer2Null()
    {
        PlayerDetails player2=new PlayerDetails();
        assertTrue(player2.IsPlayer2Null());
    }


}
