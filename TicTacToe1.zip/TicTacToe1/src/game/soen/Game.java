package game.soen;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

/**
 * @author Amritpal
 *
 */
public class Game extends JFrame implements ActionListener{
	JButton[] button=new JButton[9];
	JPanel content = new JPanel();
	JPanel window = new JPanel();
	JMenuBar bar=new JMenuBar();
	//JMenu home=new JMenu("Home");
	JMenuItem home=new JMenuItem();
	JMenuItem Reset =new JMenuItem();
	JMenuItem Help =new JMenuItem();
	boolean flag;
	//JButton home =new JButton();
	/**
	 * Creates a new game matrix
	 * @param Player1 String
	 * @param Player2 String
	 * @param Symbol String
	 */
	public void createGame(String Player1,String Player2,String Symbol){
		
		
		setDefaultLookAndFeelDecorated(true);
		if(Symbol.equalsIgnoreCase("x"))
		{
			flag=true;	
		}
		else
		{
			flag=false;
		}
		
		
		/////////////
		
		Reset.addActionListener(this);
		Reset.setIcon(new ImageIcon(Game.class.getResource("/game/soen/reset.png")));
		//Reset.addMouseMotionListener(l);
		
		
		home.setIcon(new ImageIcon(Game.class.getResource("/game/soen/home.png")));
		home.addActionListener(this);
		
		
		Help.setIcon(new ImageIcon(Game.class.getResource("/game/soen/help.png")));
		Help.addActionListener(this);
		
		
		bar.add(home);
		bar.add(Reset);
		bar.add(Help);
		getContentPane().add(bar);
		
		
		
		
		
		
		
		
		window.setBackground(new Color(102, 153, 153));
		
		
		content.setLayout(new BorderLayout());
		
		window.setLayout(new GridLayout(3,3,3,3));
		setSize(300,300);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
				
		for(int i=0;i<9;i++){
			button[i]=new JButton();
			window.add(button[i]);
			button[i].addActionListener(this);
	        

		}
		
		content.add(bar, BorderLayout.BEFORE_FIRST_LINE);
		content.add(window,BorderLayout.CENTER);
		getContentPane().add(content);
		setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		
		
		// TODO Auto-generated method stub
		
		if(e.getSource()==home)
		{
			HomePage homepage=new HomePage();
			dispose();
		}
		
		else if (e.getSource()==Reset) {
			for(int i=0;i<9;i++)
			{
				
				button[i].setIcon(null);
			}
			
			
		}
		else if (e.getSource()==Help) {
			Help help =new Help();
			
			
		}
		
		else
		{
		for(int i=0;i<9;i++)
		{
		   
			if(e.getSource()==button[i])
				
			{
				if(button[i].getIcon()==null)
		      {
		    	  if(flag){
		           //button[i].setText("x");
		           button[i].setIcon(new ImageIcon(Game.class.getResource("/game/soen/ic1.jpg")));
		           window.setBackground(new Color(255, 153, 153));
		         //  button[i].setEnabled(false);
		           flag=false;
		    	  }
		    	  else
		    	  {
		    		  //button[i].setText("o");
			         //  button[i].setEnabled(false);
			           button[i].setIcon(new ImageIcon(Game.class.getResource("/game/soen/ic2.jpg")));
			           window.setBackground(new Color(153, 255, 153));
			           flag=true;
		    		  
		    		  
		    	  }
		           
		      }
			}
		
		}
		}
}
}