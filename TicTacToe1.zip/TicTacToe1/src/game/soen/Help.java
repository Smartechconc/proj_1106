package game.soen;

import javax.swing.JFrame;
import java.awt.Toolkit;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

/**
 * @author Amritpal
 *
 */
public class Help {



public Help(){
	
	JFrame help =new JFrame();
	JFrame.setDefaultLookAndFeelDecorated(true);
	help.setIconImage(Toolkit.getDefaultToolkit().getImage(Help.class.getResource("/game/soen/help.png")));
	help.getContentPane().setLayout(null);
	help.setResizable(false);
 
	
	JTextArea txtrTictactoeIsGame = new JTextArea();
	txtrTictactoeIsGame.setText("TicTacToe  is game for two players\r\n, X and O, who take turns marking \r\nthe spaces in a 3\u00D73 grid. The player\r\nwho succeeds in placing three of \r\ntheir marks in a horizontal, vertical,\r\nor diagonal row wins the game.\r\n");
	txtrTictactoeIsGame.setBounds(0, 84, 284, 177);
	txtrTictactoeIsGame.setEditable(false);
	help.getContentPane().add(txtrTictactoeIsGame);
	
	JLabel lblNewLabel = new JLabel("");
	lblNewLabel.setBounds(0, 0, 140, 80);
	lblNewLabel.setIcon(new ImageIcon(Help.class.getResource("/game/soen/TicTacToe1.gif")));
	help.getContentPane().add(lblNewLabel);
	
	JLabel lblNewLabel_1 = new JLabel("");
	lblNewLabel_1.setIcon(new ImageIcon(Help.class.getResource("/game/soen/TicTacToe1.gif")));
	lblNewLabel_1.setBounds(141, 0, 140, 80);
	help.getContentPane().add(lblNewLabel_1);
	
	JLabel lblNewLabel_2 = new JLabel("New label");
	lblNewLabel_2.setIcon(new ImageIcon(Help.class.getResource("/game/soen/bg.jpg")));
	lblNewLabel_2.setBounds(0, 0, 284, 261);
	help.getContentPane().add(lblNewLabel_2);
	help.setSize(300, 300);
	help.setVisible(true);

	
}
}
