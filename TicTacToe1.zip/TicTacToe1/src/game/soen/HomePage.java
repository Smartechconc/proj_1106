package game.soen;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;

/**
 * @author Amritpal
 *
 */
public class HomePage extends JFrame{
	/**
	 * Create home page Frame 
	 */
	public HomePage(){
		
		
		
		
		
		
		setDefaultLookAndFeelDecorated(true);
		
		JPanel homePanel=new JPanel();
		homePanel.setLayout(null);
		JFrame homeFrame=new JFrame("Home");
		
		JFrame.setDefaultLookAndFeelDecorated(true);
		homeFrame.setSize(300,300);
		homeFrame.setResizable(false);
		
		homeFrame.getContentPane().setLayout(null);
		
		
		/**
		 * To start a new game, player will click on New Game Button
		 */
		JButton btnNewButton = new JButton("New Game");
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		btnNewButton.setFont(new Font("Lucida Handwriting", Font.BOLD, 14));
		
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				PlayerDetails details=new PlayerDetails();
				details.createPlayer();	
				homeFrame.dispose();
				homeFrame.setDefaultCloseOperation(EXIT_ON_CLOSE);

				
			}
		});
		/**
		 * To exit the game player clicks on the exit button
		 * 
		 */
		JButton btnNewButton_1 = new JButton("Exit");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				JDialog.setDefaultLookAndFeelDecorated(true);
			    int response = JOptionPane.showConfirmDialog(null, "Do you want to continue?", "Confirm",
			        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
			    if (response == JOptionPane.NO_OPTION) {
			      } else if (response == JOptionPane.YES_OPTION) {
					System.exit(ABORT);

			        
			        
			      } else if (response == JOptionPane.CLOSED_OPTION) {
			        
			        
			      }
				
			}
		});
		
		JLabel lblDevelopedByGroup = new JLabel("Developed by Group 10");
		lblDevelopedByGroup.setFont(new Font("Tahoma", Font.PLAIN, 8));
		lblDevelopedByGroup.setBounds(188, 246, 96, 14);
		homeFrame.getContentPane().add(lblDevelopedByGroup);
		btnNewButton_1.setFont(new Font("Lucida Handwriting", Font.BOLD, 14));
		btnNewButton_1.setBackground(Color.LIGHT_GRAY);
		btnNewButton_1.setBounds(81, 168, 142, 37);
		homeFrame.getContentPane().add(btnNewButton_1);
		btnNewButton.setBounds(81, 78, 142, 37);
		homeFrame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(HomePage.class.getResource("/game/soen/bg.jpg")));
		lblNewLabel.setBounds(0, 0, 294, 271);
		homeFrame.getContentPane().add(lblNewLabel);
		homeFrame.setVisible(true);
		

	}
	
	public static void main(String[] s){
				new HomePage();
	}
}
