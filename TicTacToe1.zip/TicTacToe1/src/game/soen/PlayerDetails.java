package game.soen;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.Color;

/**
 * @author Amritpal
 *
 */
public class PlayerDetails extends JFrame{
	private JTextField txtPalyername1;
	private JTextField txtPalyername2;


/** 
 * Create the player Details Frame
 */
public void createPlayer(){
	setDefaultLookAndFeelDecorated(true);
	JFrame playerDetails=new JFrame("Details");
	playerDetails.getContentPane().setLayout(null);
	playerDetails.setSize(400, 400);
	
	JLabel lblName = new JLabel("Player 1");
	lblName.setForeground(Color.BLACK);
	lblName.setFont(new Font("Lucida Handwriting", Font.BOLD, 20));
	lblName.setBounds(10, 47, 121, 34);
	playerDetails.getContentPane().add(lblName);
	setResizable(false);
	
	/*
	 * Enter Player 1 name
	 */
	txtPalyername1 = new JTextField();
	txtPalyername1.setText("player1");
	txtPalyername1.setBounds(189, 57, 139, 20);
	playerDetails.getContentPane().add(txtPalyername1);
	txtPalyername1.setColumns(10);
	

	/*
	 * Enter Player 2 name
	 */
	txtPalyername2 = new JTextField();
	txtPalyername2.setText("player2");
	txtPalyername2.setBounds(189, 110, 139, 20);
	playerDetails.getContentPane().add(txtPalyername2);
	txtPalyername2.setColumns(10);
	
	
	JLabel lblSelectSymbol = new JLabel("Select \nSymbol");
	lblSelectSymbol.setForeground(Color.BLACK);
	lblSelectSymbol.setFont(new Font("Lucida Handwriting", Font.BOLD, 20));
	lblSelectSymbol.setBounds(10, 156, 173, 34);
	playerDetails.getContentPane().add(lblSelectSymbol);
	
	JRadioButton rdbtnX = new JRadioButton("X");
	rdbtnX.setForeground(new Color(0, 0, 0));
	rdbtnX.setFont(new Font("Brush Script MT", Font.BOLD | Font.ITALIC, 22));
	rdbtnX.setBounds(189, 164, 39, 23);
	rdbtnX.setSelected(true);
	playerDetails.getContentPane().add(rdbtnX);
	
	
	
	JRadioButton radioButton = new JRadioButton("O");
	radioButton.setFont(new Font("Brush Script MT", Font.BOLD | Font.ITALIC, 22));
	radioButton.setBounds(189, 191, 39, 23);
	playerDetails.getContentPane().add(radioButton);
	
	
	
	JLabel lblPlayer = new JLabel("Player 2");
	lblPlayer.setForeground(Color.BLACK);
	lblPlayer.setFont(new Font("Lucida Handwriting", Font.BOLD, 20));
	lblPlayer.setBounds(10, 100, 121, 35);
	playerDetails.getContentPane().add(lblPlayer);
	
	
	JButton btnStartGame = new JButton("Start Game");
	btnStartGame.setBackground(Color.LIGHT_GRAY);
	btnStartGame.setFont(new Font("Lucida Handwriting", Font.BOLD, 15));
	btnStartGame.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			
			Game game=new Game();
			if(txtPalyername1.getText().equals(null)){
				
				txtPalyername1.setText("Player1");
				
			}
			if(txtPalyername2.getText().equals(null)){
				
				txtPalyername2.setText("Player2");
				
			}
			
			if(rdbtnX.isSelected()){
			game.createGame(txtPalyername1.getText(),txtPalyername2.getText(), rdbtnX.getText());
			playerDetails.dispose();
			}
			else
			{
				
				
				game.createGame(txtPalyername1.getText(),txtPalyername2.getText(), radioButton.getText());
			}
			playerDetails.setDefaultCloseOperation(EXIT_ON_CLOSE);
			playerDetails.dispose();
		}
	});
	btnStartGame.setBounds(134, 251, 149, 34);
	playerDetails.getContentPane().add(btnStartGame);
	
	ButtonGroup grp =new ButtonGroup();
	grp.add(rdbtnX);
	grp.add(radioButton);
	
	
	
	JLabel lblNewLabel = new JLabel("");
	lblNewLabel.setIcon(new ImageIcon(PlayerDetails.class.getResource("/game/soen/bg.jpg")));
	lblNewLabel.setBounds(0, 0, 384, 361);
	playerDetails.getContentPane().add(lblNewLabel);
	
	
	
	playerDetails.setVisible(true);
 }
}
