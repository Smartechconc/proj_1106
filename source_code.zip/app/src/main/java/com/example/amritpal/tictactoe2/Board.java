package com.example.amritpal.tictactoe2;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.ActionBar;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


public class Board extends AppCompatActivity {
    //getSupportActionBar().setDisplayOptions



    ImageButton boardButtons[]=new ImageButton[9];
    Button reset;
    ProgressBar progressBar;
    Button home,help,playerSym;
    String player1,player2,Symbol,GameTyp,turn;
    int p1Counter,p2Counter,drawCounter,gameTyp_int,gameCounter,game_count_flg;
    TextView score, gameNumber,currentPlayer;
    public String getTurn() {
        return turn;
    }

    public void setTurn(String turn) {
        this.turn = turn;
    }

    public String getSymbol() {
        return Symbol;
    }

    public void setSymbol(String symbol) {
        Symbol = symbol;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_board);
        LinearLayout layout_board=(LinearLayout)findViewById(R.id.board_title);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.title_bar_board);
        home=(Button)findViewById(R.id.home);
        help=(Button)findViewById(R.id.help);
        playerSym=(Button)findViewById(R.id.currentplayersymbol);
        currentPlayer=(TextView)findViewById(R.id.currentplayer);

        boardButtons[0]=(ImageButton)findViewById(R.id.Bu_1);
        boardButtons[1]=(ImageButton)findViewById(R.id.Bu_2);
        boardButtons[2]=(ImageButton)findViewById(R.id.Bu_3);
        boardButtons[3]=(ImageButton)findViewById(R.id.Bu_4);
        boardButtons[4]=(ImageButton)findViewById(R.id.Bu_5);
        boardButtons[5]=(ImageButton)findViewById(R.id.Bu_6);
        boardButtons[6]=(ImageButton)findViewById(R.id.Bu_7);
        boardButtons[7]=(ImageButton)findViewById(R.id.Bu_8);
        boardButtons[8]=(ImageButton)findViewById(R.id.Bu_9);

        player1=getIntent().getExtras().getString("Player1");
        player2=getIntent().getExtras().getString("Player2");
        Symbol=getIntent().getExtras().getString("Symbol");
       gameCounter=1;
        game_count_flg=0;
        ///////
        progressBar =(ProgressBar)findViewById(R.id.progressBar);
        gameNumber=(TextView)findViewById(R.id.gameNumber);
                //////

        GameTyp=getIntent().getExtras().getString("GameType");
        if(GameTyp.equalsIgnoreCase("Single Game"))
        {

            gameTyp_int=1;
            progressBar.setMax(1);
            progressBar.setProgress(1);
        }
        else if(GameTyp.equals("3-Game Series"))
        {

            gameTyp_int=3;
            progressBar.setMax(3);
            progressBar.setProgress(1);
        }
        else if(GameTyp.equals("5-Game Series"))
        {

            gameTyp_int=5;
            progressBar.setMax(5);
            progressBar.setProgress(1);
        }

        gameNumber.setText("Game 1 of "+gameTyp_int);





        score=(TextView)findViewById(R.id.score);




        setTurn(player1);
        setSymbol(Symbol);

        if(getSymbol().equalsIgnoreCase("x"))
        {

            playerSym.setBackgroundResource(R.drawable.ic_x);

        }
        else
        {
            playerSym.setBackgroundResource(R.drawable.ic_o);
        }
        currentPlayer.setText(player1+"'s Turn");

        reset=(Button)findViewById(R.id.reset);

        displayText();
       // addActionListener();



            for(int i=0;i<=8;i++){
                boardButtons[i].setBackgroundResource(R.drawable.bg);
                boardButtons[i].setContentDescription("new");
                addActionListener(boardButtons[i]);


            }





    }
    /*
        public int addActionListener(ImageButton B){

            final ImageButton clickedButton=B;
            clickedButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   // Boolean isGameWon;

                    if (clickedButton.getContentDescription().equals("new"))
                    {
                        if (getSymbol().equalsIgnoreCase("x")) {
                            clickedButton.setBackgroundResource(R.drawable.ic_x);
                            clickedButton.setContentDescription("x");
                            int mov=makeMove();
                            if(mov==0) {
                                switchTurn();
                                setSymbol("o");
                                playerSym.setBackgroundResource(R.drawable.ic_o);

                            }
                            displayText();

                        }
                        else if((getSymbol().equalsIgnoreCase("o")) )
                        {
                            clickedButton.setBackgroundResource(R.drawable.ic_o);
                            clickedButton.setContentDescription("o");
                            int mov=makeMove();
                            if(mov==0) {
                                switchTurn();
                                setSymbol("x");
                                playerSym.setBackgroundResource(R.drawable.ic_x);

                            }
                            displayText();

                        }
                   }
                    else{
                            showToast("Already taken!!Please select another box.");

                    }
                }
            });

        return 0;

        }
*/
    public void addActionListener(ImageButton B){

        final ImageButton clickedButton=B;
        clickedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Boolean isGameWon;

                if (clickedButton.getContentDescription().equals("new"))
                {
                    if (getSymbol().equalsIgnoreCase("x")) {
                        clickedButton.setBackgroundResource(R.drawable.ic_x);
                        clickedButton.setContentDescription("x");
                        int mov=makeMove();
                        if(mov==0) {
                            switchTurn();
                            setSymbol("o");
                            playerSym.setBackgroundResource(R.drawable.ic_o);

                        }
                        displayText();

                    }
                    else if((getSymbol().equalsIgnoreCase("o")) )
                    {
                        clickedButton.setBackgroundResource(R.drawable.ic_o);
                        clickedButton.setContentDescription("o");
                        int mov=makeMove();
                        if(mov==0) {
                            switchTurn();
                            setSymbol("x");
                            playerSym.setBackgroundResource(R.drawable.ic_x);

                        }
                        displayText();

                    }
                }
                else{
                    showToast("Already taken!!Please select another box.");

                }
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetBoard();
            }
        });

        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


            displayAlert("TicTacToe  is game for two players, X and O, who take turns marking the spaces in a 3x3 grid. The player who succeeds in placing three of their marks in a horizontal, vertical,or diagonal row wins the game","Help",true);
            }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent homePage=new Intent("com.example.amritpal.tictactoe2.PlayerDetails");
                startActivity(homePage);
            }
        });
    }



public boolean checkWinner(){
    for(int i=0;i<3;i++)
    {

        if(boardButtons[i].getContentDescription().equals(boardButtons[i+3].getContentDescription()) &&
                boardButtons[i].getContentDescription().equals(boardButtons[i+6].getContentDescription())


               && !boardButtons[i].getContentDescription().equals("new") )
        {

            return true;

        }




    }
    for(int j=0;j<6;j+=3)
    {

        if(boardButtons[j].getContentDescription().equals(boardButtons[j+1].getContentDescription()) &&
                boardButtons[j].getContentDescription().equals(boardButtons[j+2].getContentDescription()) && !boardButtons[j].getContentDescription().equals("new"))


        {

            return true;

        }


    }

    if( (boardButtons[0].getContentDescription().equals(boardButtons[4].getContentDescription())
            && boardButtons[0].getContentDescription().equals(boardButtons[8].getContentDescription())
    &&!boardButtons[0].getContentDescription().equals("new"))
            ||
            ( boardButtons[2].getContentDescription().equals(boardButtons[4].getContentDescription())

            && boardButtons[2].getContentDescription().equals(boardButtons[6].getContentDescription())
            )
           && !boardButtons[2].getContentDescription().equals("new") )
    {
        return true;


    }



    return false;
}

    public void resetBoard()
    {


        for (int i=0;i<9;i++)
        {
        boardButtons[i].setContentDescription("new");
            boardButtons[i].setBackgroundResource(R.drawable.bg);
        }
        setTurn(player1);
        currentPlayer.setText(player1+"'s Turn");
        setSymbol(getIntent().getExtras().getString("Symbol"));
        if (getSymbol().equalsIgnoreCase("x")){

            playerSym.setBackgroundResource(R.drawable.ic_x);
        }
        else{
            playerSym.setBackgroundResource(R.drawable.ic_o);
        }



    }



    public void switchTurn(){

        if(getTurn().equalsIgnoreCase(player1))
        {
            setTurn(player2);
           currentPlayer.setText(player2+"'s Turn");

        }
       else if(getTurn().equalsIgnoreCase(player2))
        {

            setTurn(player1);
            currentPlayer.setText(player1+"'s Turn");
        }


    }


    public Boolean checkDraw()
    {
        int counter=0;
        for (int i=0;i<=8;i++){
            if(boardButtons[i].getContentDescription()!=null) {
                if (boardButtons[i].getContentDescription().equals("x") || boardButtons[i].getContentDescription().equals("o")) {

                    counter++;
                }
            }

             }
        if(counter==9)
        {

            return true;
        }

        return false;
    }



public void displayAlert(String message,String Title,Boolean help){

    AlertDialog.Builder a_build=new AlertDialog.Builder(this);
    final boolean ishelp=help;
    a_build.setMessage(message).setCancelable(false).setNeutralButton("OK!", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            if(ishelp) {

            }
            else{

                Intent homePage=new Intent("com.example.amritpal.tictactoe2.PlayerDetails");
                startActivity(homePage);
            }
        }
    });

AlertDialog alert=a_build.create();


        alert.setTitle(Title);

    alert.show();

}
public void showToast(String msg){


    Toast.makeText(Board.this, msg, Toast.LENGTH_LONG).show();
}


    public int makeMove(){
        if(checkWinner())
        {

            if(getTurn().equalsIgnoreCase(player1))
            {

                p1Counter++;


            }
            else{


                p2Counter++;
            }

            if(gameCounter==gameTyp_int){


                if(p1Counter>p2Counter) {
                    displayAlert(player1 + " wins this Series!!!!!","We Have a Winner!!!!",false);
                }
                else if(p2Counter>p1Counter){


                    displayAlert(player2+" Wins this Series!!!!","We Have a Winner!!!!",false);

                }
                else{

                    displayAlert("The series is Drawn","Match Drawn",false);
                }


            }
            else{

                //display Toast;
                showToast(getTurn()+ " Wins this match");
                resetBoard();
                setTurn(player1);
                setSymbol(getIntent().getExtras().getString("Symbol"));
                currentPlayer.setText(player1+"'s Turn");
                if(getSymbol().equalsIgnoreCase("x")){

                    playerSym.setBackgroundResource(R.drawable.ic_x);
                }
                else{

                    playerSym.setBackgroundResource(R.drawable.ic_o);
                }
                game_count_flg=1;
                ///new Game

            }
            gameCounter++;
            if(game_count_flg==1) {
                progressBar.setProgress(gameCounter);
                gameNumber.setText("Game " + gameCounter + " of " + gameTyp_int);
                game_count_flg=0;
            }
            return 1;
        }


        if(checkDraw()){


            drawCounter++;
            if(gameCounter==gameTyp_int){
                if(p1Counter>p2Counter) {
                    displayAlert(player1 + " wins this Series!!!!!","We Have a Winner!!",false);
                }
                else if(p2Counter>p1Counter){


                    displayAlert(player2+" Wins this Series!!!!","We Have a Winner!!",false);

                }

                else{

                    displayAlert("The series is Drawn","Sereis Drawn",false);
                }

            }
            else
            {


                //display Toast
                showToast( "Match Drawn !");
                resetBoard();
                setTurn(player1);
                setSymbol(getIntent().getExtras().getString("Symbol"));
                currentPlayer.setText(player1+"'s Turn");
                if(getSymbol().equalsIgnoreCase("x")){

                    playerSym.setBackgroundResource(R.drawable.ic_x);
                }
                else{

                    playerSym.setBackgroundResource(R.drawable.ic_o);
                }

                game_count_flg=1;
                ///new Game
            }
            gameCounter++;
            if(game_count_flg==1)
            {
                progressBar.setProgress(gameCounter);

                gameNumber.setText("Game "+gameCounter+" of "+gameTyp_int);
                game_count_flg=0;

            }
            return 1;

        }




        return 0;
    }

public void displayText(){


    score.setText(player1+"'s Score -"+String.valueOf(p1Counter)+"\n"+player2+"'s Score -"+String.valueOf(p2Counter)+"\n"+"Drawn-"+String.valueOf(drawCounter));
}

}
