package com.example.amritpal.tictactoe2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class GameType extends AppCompatActivity {
Button StartGame;
    String player1,player2,Symbol;
    RadioButton GameType;
    RadioGroup symbolGrp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_type);

        player1 =getIntent().getExtras().getString("Player1");
        System.out.print("in Game Type-Player="+player1);
        TextView Player1=(TextView)findViewById(R.id.pl1);
        Player1.setText(player1+" Please Select Game Type");

        player2=getIntent().getExtras().getString("Player2");
        Symbol=getIntent().getExtras().getString("Symbol");



        StartGame=(Button)findViewById(R.id.StartGame);
        addActionListener();
    }
        public void addActionListener(){

        StartGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                symbolGrp=(RadioGroup)findViewById(R.id.rgGameType) ;
                int rgSelected=symbolGrp.getCheckedRadioButtonId();
                GameType=(RadioButton)findViewById(rgSelected);
                Intent gameBoard=new Intent("com.example.amritpal.tictactoe2.Board");
                gameBoard.putExtra("Player1",player1)  ;
                gameBoard.putExtra("Player2",player2);
                gameBoard.putExtra("Symbol",Symbol);
                gameBoard.putExtra("GameType",GameType.getText().toString());
                startActivity(gameBoard);



            }
        });


    }






}

