package com.example.amritpal.tictactoe2;

import android.app.Activity;
import android.content.Intent;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.app.Dialog;
import android.view.View.OnClickListener;

public class HomePage extends AppCompatActivity

{
    private Button newGame,exitGame;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        newGame= (Button) findViewById(R.id.Start_bu);
        exitGame=(Button) findViewById(R.id.Exit_Bu);
        addListenerOnButton();

    }

    public void addListenerOnButton(){


        exitGame.setOnClickListener(
                new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        android.os.Process.killProcess(android.os.Process.myPid());
                        System.exit(1);
                    }
                }


        );
        newGame.setOnClickListener(new OnClickListener() {
                                       @Override
                                       public void onClick(View v) {

                                          Intent playerDetails=new Intent("com.example.amritpal.tictactoe2.PlayerDetails");
                                           startActivity(playerDetails);
                                       }
                                   }
        );

    }

}
