package com.example.amritpal.tictactoe2;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class PlayerDetails extends AppCompatActivity {


    EditText Player1,Player2;
    RadioGroup Symbol;
    RadioButton X;
    Button next;
    String player1,player2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_details);
        Player1=(EditText)findViewById(R.id.player1);

        Player2=(EditText)findViewById(R.id.Player2);
        Symbol=(RadioGroup) findViewById(R.id.rgSymbol);

        player1=Player1.getText().toString();
        player2=Player2.getText().toString();
        addListenerOnButton();

    }


    public void addListenerOnButton(){



        next=(Button)findViewById(R.id.Next);
            next.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {

                    Player1=(EditText)findViewById(R.id.player1);

                    Player2=(EditText)findViewById(R.id.Player2);
                    Symbol=(RadioGroup) findViewById(R.id.rgSymbol);

                    player1=Player1.getText().toString();
                    player2=Player2.getText().toString();
                    int flg=0;
                    if (IsPlayer1Null() || IsPlayer2Null()) {
                        if(IsPlayer1Null()){
                            if(IsPlayer2Null()){
                                createMessage("Please Enter Player1 and Player2 Names");
                                    flg=1;
                            }

                            else
                            {

                                createMessage("Please Enter Player1 Name");
                            }

                        }
                        if(IsPlayer2Null() && flg==0){
                            if(IsPlayer1Null()){
                                createMessage("Please Enter Player1 and Player2 Names");
                            }
                            else {

                                createMessage("Please Enter Player2 Name");

                            }


                        }
                        

                    }
                    else
                    {


                        int rb = Symbol.getCheckedRadioButtonId();
                        X = (RadioButton) findViewById(rb);
                        Intent GameType = new Intent("com.example.amritpal.tictactoe2.GameType");
                        GameType.putExtra("Player1", Player1.getText().toString());
                        GameType.putExtra("Player2", Player2.getText().toString());
                        GameType.putExtra("Symbol", X.getText().toString());
                        startActivity(GameType);
                    }
                }
            });

    }
    private boolean IsPlayer1Null(){
        if(player1==null|| player1=="" || player1.equals(""))
        {
            return true;
        }

        return false;
    }
    private boolean IsPlayer2Null(){

        if(player1==null|| player1=="" || player1.equals(""))
        {
            return true;
        }



        return false;
    }
private void createMessage(String msg){


    AlertDialog.Builder a_build=new AlertDialog.Builder(this);
    a_build.setMessage(msg).setCancelable(false).setNeutralButton("OK!", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {


        }
    });

    AlertDialog alert=a_build.create();


    alert.setTitle("Please Enter Player Details");

    alert.show();

}

}
