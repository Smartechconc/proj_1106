package com.example.amritpal.tictactoe2;

import android.os.Bundle;

import org.junit.Test;
import com.example.amritpal.tictactoe2.Board;
import static org.junit.Assert.*;

/**
 * Created by Amritpal on 2016-05-29.
 */
public class boardTest {
@Test
public void testBoard(){


    Board test=new Board();
    test.onCreate(Bundle.EMPTY);
/*
    for(int i=0;i<=8;i++){

        test.boardButtons[i].setContentDescription("x");
    }
*/
    Boolean checkcounterval = test.checkDraw();

    assertTrue(checkcounterval);
}

}